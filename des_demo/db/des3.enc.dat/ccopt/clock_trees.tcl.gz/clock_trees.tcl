# ccopt saved state clock_trees.tcl.gz

create_ccopt_clock_tree -name core_clk -source clk -no_skew_group 
